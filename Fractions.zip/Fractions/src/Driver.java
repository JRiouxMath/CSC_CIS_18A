
public class Driver {

    public static void main(String[] args) {
        Fractions a = new Fractions();
        Fractions b = new Fractions();
        
        System.out.println("a.toString(): "+a.toString());
        System.out.println("a.getValue(): "+a.getValue());
        
        a.setNumerator(1);
        a.setDenominator(5);
        b.setNumerator(3);
        b.setDenominator(5);
        
        Fractions c = a.add(b);
                
        System.out.println("c.toString(): "+c.toString());
        System.out.println("c.getValue(): "+c.getValue());
        
        a.setNumerator(5);
        a.setDenominator(11);
        
        System.out.println("a.toString(): "+a.toString());
        System.out.println("a.getValue(): "+a.getValue());
        
        c = b.add(a);
        System.out.println("c.toString(): "+c.toString());
        System.out.println("c.getValue(): "+c.getValue());
        
    }
    
}
