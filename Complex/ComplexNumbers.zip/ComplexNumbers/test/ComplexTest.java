import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author rcc
 */
public class ComplexTest {
    
    public ComplexTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of getReal method, of class Complex.
     */
    @Test
    public void testGetReal() {
        System.out.println("getReal");
        Complex instance = new Complex(1.0,1.0);
        double expResult = 1.0;
        double result = instance.getReal();
        assertEquals(expResult, result, 0.0);        
    }

    /**
     * Test of setReal method, of class Complex.
     */
    @Test
    public void testSetReal() {
        System.out.println("setReal");
        double real = 0.0;
        Complex instance = new Complex(1.0,1.0);
        instance.setReal(real);
        double result = instance.getReal();
        assertEquals(real, result, 0.0);
    }

    /**
     * Test of getImaginary method, of class Complex.
     */
    @Test
    public void testGetImaginary() {
        System.out.println("getImaginary");
        Complex instance = new Complex(1.0,1.0);
        double expResult = 1.0;
        double result = instance.getImaginary();
        assertEquals(expResult, result, 0.0);
    }

    /**
     * Test of setImaginary method, of class Complex.
     */
    @Test
    public void testSetImaginary() {
        System.out.println("setImaginary");
        double imaginary = 0.0;
        Complex instance = new Complex(1.0,1.0);
        instance.setImaginary(imaginary);
        double result = instance.getImaginary();
        assertEquals(imaginary, result, 0.0);
    }

    /**
     * Test of add method, of class Complex.
     */
    @Test
    public void testAdd() {
        System.out.println("add");
        Complex c2 = new Complex(2,3);
        Complex instance = new Complex(1,2);
        Complex expResult = new Complex(3,5);
        Complex result = instance.add(c2);
        assertEquals(expResult.getReal(), result.getReal(), 0.0);        
        assertEquals(expResult.getImaginary(), result.getImaginary(), 0.0);        
    }

    /**
     * Test of subtract method, of class Complex.
     */
    @Test
    public void testSubtract() {
        System.out.println("subtract");
        Complex c2 = new Complex(2,2);
        Complex instance = new Complex(3,4);
        Complex expResult = new Complex(1,2);
        Complex result = instance.subtract(c2);
        assertEquals(expResult.getReal(), result.getReal(), 0.0);        
        assertEquals(expResult.getImaginary(), result.getImaginary(), 0.0);
    }

    /**
     * Test of multiply method, of class Complex.
     */
    @Test
    public void testMultiply() {
        System.out.println("multiply");
        Complex c2 = new Complex(2,2);
        Complex instance = new Complex(3,4);
        Complex expResult = new Complex(-2,14);
        Complex result = instance.multiply(c2);
        assertEquals(expResult.getReal(), result.getReal(), 0.0);        
        assertEquals(expResult.getImaginary(), result.getImaginary(), 0.0);
    }
    
    @Test
    public void testMultiply2() {
        System.out.println("multiply test #2");
        Complex c2 = new Complex(0,1);
        Complex instance = new Complex(3,4);
        Complex expResult = new Complex(-4,3);
        Complex result = instance.multiply(c2);
        assertEquals(expResult.getReal(), result.getReal(), 0.0);        
        assertEquals(expResult.getImaginary(), result.getImaginary(), 0.0);
    }

    /**
     * Test of divide method, of class Complex.
     */
    @Test
    public void testDivide() {
        System.out.println("divide");
        Complex c2 = new Complex(2,2);
        Complex instance = new Complex(3,4);
        Complex expResult = new Complex(1.75,0.25);
        Complex result = instance.divide(c2);
        assertEquals(expResult.getReal(), result.getReal(), 0.0);        
        assertEquals(expResult.getImaginary(), result.getImaginary(), 0.0);
    }
    
}
